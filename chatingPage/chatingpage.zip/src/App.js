import ChatingRoom from "./pages/chatingPage/ChatingRoom";
import ChatingList from "./pages/chatingPage/ChatingList";

function App() {
    return (
        <div>
            <ChatingRoom />
        </div>
    );
}
export default App;
